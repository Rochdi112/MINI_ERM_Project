from django.db import migrations

class Migration(migrations.Migration):

    dependencies = [
        ('app_clients', '0003_alter_client_options_client_email_client_telephone_and_more'),  # dépendance corrigée
    ]

    operations = [
    ]
