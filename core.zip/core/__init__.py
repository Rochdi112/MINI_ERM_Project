# Vide requis pour que Python traite le dossier comme un package
default_app_config = 'core.apps.CoreConfig'
