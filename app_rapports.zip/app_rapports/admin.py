from django.contrib import admin
from .models import Rapport

admin.site.register(Rapport)
