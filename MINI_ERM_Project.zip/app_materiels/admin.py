from django.contrib import admin
from .models import Materiel

admin.site.register(Materiel)
