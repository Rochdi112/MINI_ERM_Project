from django.contrib import admin
from .models import Intervention

admin.site.register(Intervention)
