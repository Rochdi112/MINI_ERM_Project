from django.contrib import admin
from .models import Technicien

admin.site.register(Technicien)
